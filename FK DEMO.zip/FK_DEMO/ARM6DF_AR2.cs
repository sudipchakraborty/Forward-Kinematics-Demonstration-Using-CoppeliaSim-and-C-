﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using SharpGL;

namespace Tools 
{
    class arm
    {
      //  OpenGL gl = new OpenGL();

        int dof;
        dh_param[] dh;

       

       public struct dh_param
        {
            public double theta;
            public double alpha;
            public double d;
            public double a;
        };

        public struct Work_Frame
        {
            public double X;
            public double Y;
            public double Z;

            public double yx;
            public double py;
            public double rz;
        };

        public struct Tool_Frame
        {
            public double X;
            public double Y;
            public double Z;

            public double yx;
            public double py;
            public double rz;
        };


        //string dh_param =
        //       "0.174532925,-1.570796327,169.77,64.2," +
        //       "-1.570796327,0,0,305," +
        //       "0.1745322925,1.570796327,0,0," +
        //       "0.785398163,-1.570796327,-222.63,0," +
        //       "0.436332313,1.570796327,0,0," +
        //       "3.926990817,0,-36.25,0";

        //arm = new arm(6, dh_param);


        //double X = 311.0331182;
        //double Y = 43.84360337;
        //double Z = 419.7374896;
        //double y = 6.307994695;
        //double p = 116.8511973;
        //double r = -80.43052397;

        //txt_msg.Text= arm.IK(X, Y, Z, y, p, r);


        //arm.push_angle_to_DH_Param("25,50,75,100,125,150");
        //    //string angle = "10,-90,100,45,25,45";/
        //    //string pos = arm.get_position(angle);
        //    txt_msg.Text = arm.Get_FK();



        //_______________________________________________________________________________________________
        public arm(int df,string dh_value)
        {
            this.dof = df;
            dh = new dh_param[df];
                    
            string[] s = dh_value.Split(',');

            if (s.Length != (dof * 4)) return;

            int index = 0;

            for(int i=0;i<dof;i++)
            {
                dh[i].theta = Convert.ToDouble(s[index++]);
                dh[i].alpha = Convert.ToDouble(s[index++]);
                dh[i].d = Convert.ToDouble(s[index++]);
                dh[i].a = Convert.ToDouble(s[index++]);
            }
        }
        //_______________________________________________________________________________________________
        public string load_default_DH_Param()
        {
            return "";
        }
        //_______________________________________________________________________________________________
        public string IK(double X, double Y, double  Z, double y, double p, double r)
        {
            double B8 = 25;
            double O25 = 90;// IFERROR(DEGREES(ATAN(ABS(E16) / F15)), 90);

            double[] angle = new double[6];

            double[] R0T = new double[16];
            R0T[0] = Math.Cos(utilIK.ToRadians(y)) * Math.Cos(utilIK.ToRadians(r)) - Math.Cos(utilIK.ToRadians(p)) * Math.Sin(utilIK.ToRadians(y)) * Math.Sin(utilIK.ToRadians(r));
            R0T[1] = Math.Cos(utilIK.ToRadians(p)) * Math.Cos(utilIK.ToRadians(r)) * Math.Sin(utilIK.ToRadians(y)) + Math.Cos(utilIK.ToRadians(y)) * Math.Sin(utilIK.ToRadians(r));
            R0T[2] = Math.Sin(utilIK.ToRadians(y)) * Math.Sin(utilIK.ToRadians(p));
            R0T[3] = 0;

            R0T[4] = Math.Cos(utilIK.ToRadians(r)) * Math.Sin(utilIK.ToRadians(y)) + Math.Cos(utilIK.ToRadians(y)) * Math.Cos(utilIK.ToRadians(p)) * Math.Sin(utilIK.ToRadians(r));
            R0T[5] = Math.Cos(utilIK.ToRadians(y)) * Math.Cos(utilIK.ToRadians(p)) * Math.Cos(utilIK.ToRadians(r)) - Math.Sin(utilIK.ToRadians(y)) * Math.Sin(utilIK.ToRadians(r));
            R0T[6] = Math.Cos(utilIK.ToRadians(y)) * Math.Sin(utilIK.ToRadians(p));
            R0T[7] = 0;

            R0T[8] = Math.Sin(utilIK.ToRadians(p)) * Math.Sin(utilIK.ToRadians(r));
            R0T[9] = Math.Cos(utilIK.ToRadians(r)) * Math.Sin(utilIK.ToRadians(p));
            R0T[10]=-Math.Cos(utilIK.ToRadians(p));
            R0T[11] = 0;

            R0T[12] = X;
            R0T[13] = Y;
            R0T[14] = Z;
            R0T[15] = 1;
            //////////////////////////////////////////////
            double[] R06 = Multiply_With_Identity(R0T); R06[0] *= -1;
           
            double[] RR06 = new double[16];
            
            RR06[0] = Math.Cos(utilIK.ToRadians(180));
            RR06[1] = -Math.Sin(utilIK.ToRadians(180)) * Math.Cos(dh[5].alpha);
            RR06[2] = Math.Sin(utilIK.ToRadians(180)) * Math.Sin(dh[5].alpha);
            RR06[3] = 0;

            RR06[4] = Math.Sin(utilIK.ToRadians(180));
            RR06[5] = Math.Cos(utilIK.ToRadians(180)) * Math.Cos(dh[5].alpha);
            RR06[6] = -Math.Cos(utilIK.ToRadians(180)) * Math.Sin(dh[5].alpha);
            RR06[7] = 0;

            RR06[8] = 0;
            RR06[9] = Math.Sin(dh[5].alpha);
            RR06[10] = Math.Cos(dh[5].alpha);
            RR06[11]= 0;

            RR06[12]= 0;
            RR06[13]= 0;
            RR06[14]= -dh[5].d;
            RR06[15]= 1;

            double[] R05 = multiply(R06, RR06);

            //______________<J1>_______________________________________________
            double _O13 = Math.Atan((R05[13]) / (R05[12]));

            double V9 = 0;
            if ((X > 0) && (Y > 0)) V9 = 1;
            if ((X > 0) && (Y < 0)) V9 = 2;
            if ((X < 0) && (Y < 0)) V9 = 3;
            if ((X < 0) && (Y > 0)) V9 = 4;

            switch(V9)
            {
                case 1: angle[0] = utilIK.ToDegrees(_O13);          break;
                case 2: angle[0] = utilIK.ToDegrees(_O13);          break;
                case 3: angle[0] = -180 + utilIK.ToDegrees(_O13);   break;
                case 4:  angle[0] = 180 + utilIK.ToDegrees(_O13);   break;
                default: break;
            }
            angle[0] = Math.Round(angle[0], 5);
            ///////////////////////////////////////////////////////////////////  
            double[] J1 = new double[16];
            J1[0] = Math.Cos(utilIK.ToRadians(angle[0]));
            J1[1] = Math.Sin(utilIK.ToRadians(angle[0]));
            J1[2] = 0;
            J1[3] = 0;

            J1[4] = -Math.Sin(utilIK.ToRadians(angle[0])) * Math.Cos(dh[0].alpha);
            J1[5] = Math.Cos(utilIK.ToRadians(angle[0])) * Math.Cos(dh[0].alpha);
            J1[6] = Math.Sin(dh[0].alpha);
            J1[7] = 0;

            J1[8] = Math.Sin(utilIK.ToRadians(angle[0])) * Math.Sin(dh[0].alpha);
            J1[9] = -Math.Cos(utilIK.ToRadians(angle[0])) * Math.Sin(dh[0].alpha);
            J1[10] = Math.Cos(dh[0].alpha);
            J1[11] = 0;

            J1[12] = dh[0].a * Math.Cos(utilIK.ToRadians(angle[0]));
            J1[13] = dh[0].a * Math.Sin(utilIK.ToRadians(angle[0]));
            J1[14] = dh[0].d;
            J1[15] = 1;

            //string st = J1[5].ToString();
            //decimal myDecimalValue = Decimal.Parse(st, System.Globalization.NumberStyles.Float);
            //myDecimalValue = Math.Round(myDecimalValue, 10);
            //double d = (double)myDecimalValue;

            double[] R01 = Multiply_With_Identity(J1);
            ///////////////////////////////////////////////////////////////////
            double O16 = Math.Sqrt(Math.Abs(R05[13] * R05[13]) + (Math.Abs(R05[12] * R05[12])));
            double O17 = R05[14] - dh[0].d;
            double O18 = O16 - dh[0].a;
            double O19 = Math.Sqrt((O17 * O17) + (O18 * O18));
            double O20 = Math.Sqrt((dh[3].d * dh[3].d) + (dh[2].a * dh[2].a));
            double O21 = utilIK.ToDegrees(Math.Atan(O17 / O18));
            double O22 = utilIK.ToDegrees(Math.Acos(((dh[1].a * dh[1].a + O19 * O19) - Math.Abs(O20 * O20)) / (2 * dh[1].a * O19)));
            double O23 = 180 - utilIK.ToDegrees(Math.Acos(((Math.Abs(O20 * O20) + (dh[1].a * dh[1].a) - (O19 * O19)) / (2 * Math.Abs(O20) * dh[1].a))) + (90 - O25));
           
            double P18 = -O18;
            double P19= Math.Sqrt((O17 * O17) + ((-O18)*(-O18)));
            double P21=utilIK.ToDegrees(Math.Acos(((dh[1].a * dh[1].a) + (P19 * P19) - Math.Abs(dh[3].d* dh[3].d))/ (2 * dh[1].a * P19)));
            double P22= (utilIK.ToDegrees(Math.Atan(P18 / O17)));      
            double P23 = 180 - utilIK.ToDegrees(Math.Acos(((Math.Abs(O20 * O20) + (dh[1].a * dh[1].a) - (P19 * P19)) / (2 * Math.Abs(O20) * dh[1].a))) + (90 - O25));
            double P24 = 90 - (P21 + P22);
            //________<J2>________________________________________________________________
            if (O18 < 0)
            {
                angle[1] = -180 + P24;
            }
            else
            {
                angle[1] = -(O21 + O22);
            }
            angle[1] = Math.Round(angle[1], 5);
            //_____________________________________________________________________________
            double[] J2 = new double[16];
            J2[0] = Math.Cos(utilIK.ToRadians(angle[1]));
            J2[1] = Math.Sin(utilIK.ToRadians(angle[1]));
            J2[2] = 0;
            J2[3] = 0;

            J2[4] = -Math.Sin(utilIK.ToRadians(angle[1])) * Math.Cos(dh[1].alpha);
            J2[5] = Math.Cos(utilIK.ToRadians(angle[1])) * Math.Cos(dh[1].alpha);
            J2[6] = Math.Sin(dh[1].alpha);
            J2[7] = 0;

            J2[8] = Math.Sin(utilIK.ToRadians(angle[1])) * Math.Sin(dh[1].alpha);
            J2[9] = -Math.Cos(utilIK.ToRadians(angle[1])) * Math.Sin(dh[1].alpha);
            J2[10] = Math.Cos(dh[1].alpha);
            J2[11] = 0;

            J2[12] = dh[1].a * Math.Cos(utilIK.ToRadians(angle[1]));
            J2[13] = dh[1].a * Math.Sin(utilIK.ToRadians(angle[1]));
            J2[14] = dh[1].d;
            J2[15] = 1;

            double[] R02 = multiply(R01, J2);// new double[16];
           //___________<J3>_____________________________________________________
            O18 = O16 - dh[0].a;
            double O27 = O23;

            if (O18 < 0)
            {
                angle[2] = P23;
            }
            else
            {
                angle[2] = O27;
            }
            angle[2] = Math.Round(angle[2], 5);
            //____________________________________________________________________        


            ///////////////////////////////////////////////////////////////////
            double[] J3 = new double[16];
            J3[0] = Math.Cos(utilIK.ToRadians((angle[2]) - 90));
            J3[1] = Math.Sin(utilIK.ToRadians((angle[2]) - 90));
            J3[2] = 0;
            J3[3] = 0;

            J3[4] = -Math.Sin(utilIK.ToRadians((angle[2]) - 90)) * Math.Cos(dh[2].alpha);
            J3[5] = Math.Cos(utilIK.ToRadians((angle[2]) - 90)) * Math.Cos(dh[2].alpha);
            J3[6] = Math.Sin(dh[2].alpha);
            J3[7] = 0;

            J3[8] = Math.Sin(utilIK.ToRadians((angle[2]) - 90)) * Math.Sin(dh[2].alpha);
            J3[9] = -Math.Cos(utilIK.ToRadians((angle[2]) - 90)) * Math.Sin(dh[2].alpha);
            J3[10] = Math.Cos(dh[2].alpha);
            J3[11] = 0;

            J3[12] = dh[2].a * Math.Cos(utilIK.ToRadians((angle[2]) - 90));
            J3[13] = dh[2].a * Math.Sin(utilIK.ToRadians((angle[2]) - 90));
            J3[14] = dh[2].d;
            J3[15] = 1;
            /////////////////////////////////////////////////////////////////////////////////////                                          
            double[] R03 = multiply(R02, J3);
            
            double[] R03T = new double[9];
            R03T[0] = R03[0];
            R03T[1] = R03[4];
            R03T[2] = R03[8];

            R03T[3] = R03[1];
            R03T[4] = R03[5];
            R03T[5] = R03[9];

            R03T[6] = R03[2];
            R03T[7] = R03[6];
            R03T[8] = R03[10];

            double[] R36 = multiply_3x3(R03T, R05);                  
            //___________________________________________________________________          
            double R8 = utilIK.ToDegrees(Math.Atan2(Math.Sqrt(1 - R36[8] * R36[8]),R36[8]));
            double S8 = utilIK.ToDegrees(Math.Atan2(-Math.Sqrt(1 - R36[8] * R36[8]),R36[8]));
            //_________<J5>_______________________________________________________
            if((B8>0) && (R8>0))
            {
                angle[4] = R8;
            }
            else
            {
                angle[4] = S8;
            }
            angle[4] = Math.Round(angle[4], 5);
            //______________________________________________________________




            //______________<Execute j6_______________________________________
            double R9 = 0;

            if (R36[5] < 0)
            {
               R9= utilIK.ToDegrees(Math.Atan2(-R36[5], R36[2])) - 180;
            }
            else
            {
               R9= utilIK.ToDegrees(Math.Atan2(-R36[5], R36[2])) + 180;
            }
            //////
            double S9;

            if (R36[5] < 0)
            {
               S9=utilIK.ToDegrees(Math.Atan2(R36[5],-R36[2])) + 180;
            }
            else
            {
                S9=utilIK.ToDegrees(Math.Atan2(R36[5],-R36[2])) - 180;
            }

            if(angle[4]<0)
            {
                angle[5] = S9;
            }
            else
            {
                angle[5] = R9;
            }
            angle[5] = Math.Round(angle[5], 5);
            //______________________________________________________________________





            //________<J4>__________________________________________________________

            double R7 = utilIK.ToDegrees(Math.Atan2(R36[6],R36[7]));
            double S7 = utilIK.ToDegrees(Math.Atan2(-R03[6], -R03[7]));

            if (angle[4] > 0)
            {
                angle[3] = R7;
            }
            else
            {
                angle[3] =S7;
            }
            angle[3] = Math.Round(angle[3], 5);
            //____________________________________________________________________
            String s = "J1=" + angle[0].ToString() +"\r\n"+
                    "J2=" + angle[1].ToString() + "\r\n" +
                    "J3=" + angle[2].ToString() + "\r\n" +
                    "J4=" + angle[3].ToString() + "\r\n" +
                    "J5=" + angle[4].ToString() + "\r\n" +
                    "J6=" + angle[5].ToString();

            return s;
        }
        //________________________________________________________________________________________________
        public string get_position(string angle)
        {
            push_angle_to_DH_Param(angle);

            //string[] prm = Get_DH_Param();
            //frm_DH d_param = new frm_DH(prm);

            Work_Frame wf = new Work_Frame();
            Tool_Frame tf = new Tool_Frame();

            wf.X = 0; wf.Y = 0; wf.Z = 0; wf.yx = 0; wf.py = 0; wf.rz = 0;
            tf.X = 0; tf.Y = 0; tf.Z = 0; tf.yx = 0; tf.py = 0; tf.rz = 0;


             Get_FK();

            //  frm_matrix mtx0 = new frm_matrix(Get_matrix(dh[0]), "J1 Matrix");
            //  frm_matrix mtx1 = new frm_matrix(Get_matrix(dh[1]), "J2 Matrix");
            //frm_matrix mtx2 = new frm_matrix(Get_matrix(dh[2]), "J3 Matrix");
            //frm_matrix mtx3 = new frm_matrix(Get_matrix(dh[3]), "J4 Matrix");
            //frm_matrix mtx4 = new frm_matrix(Get_matrix(dh[4]), "J5 Matrix");
            //frm_matrix mtx5 = new frm_matrix(Get_matrix(dh[5]), "J6 Matrix");





            return "";
        }
        //________________________________________________________________________________________________
        public double[] Get_matrix(dh_param dh)
        {
            double[] mat = new double[16];

  
            mat[0]=Math.Round(Math.Cos(dh.theta),9);
            mat[1]= Math.Round(Math.Sin(dh.theta),9);
            mat[2]= 0;
            mat[3]= 0;

            mat[4] = Math.Round(-Math.Sin(dh.theta) * Math.Cos(dh.alpha), 9);
            mat[5] = Math.Round(Math.Cos(dh.theta) * Math.Cos(dh.alpha),9);
            mat[6] = Math.Round((Math.Sin(dh.alpha)),9);
            mat[7] = 0;

            mat[8] = Math.Round((Math.Sin(dh.theta)) * (Math.Sin(dh.alpha)),9);
            mat[9] = Math.Round((-Math.Cos(dh.theta)) * (Math.Sin(dh.alpha)),9);
            mat[10] = Math.Round(Math.Cos(dh.alpha),9);
            mat[11] = 0;

            mat[12] = Math.Round(dh.a* (Math.Cos(dh.theta)),9);
            mat[13] = Math.Round((dh.a) * (Math.Sin(dh.theta)),9);
            mat[14] = Math.Round(dh.d, 9);
            mat[15] = 1;

            return mat;
        }
        //__________________________________________________________________________________________________________
        public void push_angle_to_DH_Param(string angle)
        {
            string[] s = angle.Split(',');

            double d = Convert.ToDouble(s[0]);
            d = utilIK.ToRadians(d);
            d = Math.Round(d, 9);
            dh[0].theta = d;

            d = Convert.ToDouble(s[1]);         
            d = utilIK.ToRadians(d);
            d = Math.Round(d, 9);
            dh[1].theta = d;

            d = Convert.ToDouble(s[2]);
            d = utilIK.ToRadians(d - 90);
            d = Math.Round(d, 9);
            dh[2].theta = d;

            d = Convert.ToDouble(s[3]);
            d = utilIK.ToRadians(d);
            d = Math.Round(d, 9);
            dh[3].theta = d;

            d = Convert.ToDouble(s[4]);
            d = utilIK.ToRadians(d);
            d = Math.Round(d, 9);
            dh[4].theta = d;

            d = Convert.ToDouble(s[5]);
            d = utilIK.ToRadians(d + 180);
            d = Math.Round(d, 9);
            dh[5].theta = d;
        }
        //__________________________________________________________________________________________________________________________
       public string[] Get_DH_Param()
        {
            string[] str_dh = new string[24];

            int index = 0;
            for (int i = 0; i < 6; i++)
            {
                str_dh[index++] = dh[i].theta.ToString();
                str_dh[index++] = dh[i].alpha.ToString();
                str_dh[index++] = dh[i].d.ToString();
                str_dh[index++] = dh[i].a.ToString();
            }           
            return str_dh;
        }
        //____________________________________________________________________________________________
        public String Get_FK()
        {
            string[] val = new string[6];

            double[] tmp, R06;
            tmp = utilIK.Get_Identity();
      
            tmp = multiply(tmp, Get_matrix(dh[0])); // R01
            tmp = multiply(tmp, Get_matrix(dh[1])); // R02
            tmp = multiply(tmp, Get_matrix(dh[2])); // R03
            tmp = multiply(tmp, Get_matrix(dh[3])); // R04
            tmp = multiply(tmp, Get_matrix(dh[4])); // R05
            R06 = multiply(tmp, Get_matrix(dh[5]));

           double[] R0T = multiply(R06, utilIK.Get_Identity());

           val[0] = R0T[12].ToString();
           val[1] = R0T[13].ToString();
           val[2] = R0T[14].ToString();

           double pp = Math.Atan2(Math.Sqrt((R0T[8]* R0T[8]) + (R0T[9] * R0T[9])), -R0T[10]);
           double yy = Math.Atan2((R0T[2] / pp), (R0T[6] / pp));
           double rr=Math.Atan2((R0T[8] / pp), (R0T[9] / pp));

           pp =utilIK.ToDegrees(pp);
           yy = utilIK.ToDegrees(yy);
           rr = utilIK.ToDegrees(rr);

           val[3] = yy.ToString();
           val[4] = pp.ToString();
           val[5] = rr.ToString();

           string s = "X=" + val[0] + "\r\nY=" + val[1] + "\r\nZ=" + val[2] + "\r\n" +
                         "y= " + val[3] + "\r\np = " + val[4] + "\r\nr = " + val[5];
            return s;
        }
        //____________________________________________________________________________________________________________
        public double[] Multiply_With_Identity(double[] a)
        {
            double[] mat = utilIK.Get_Identity();
            return multiply(a, mat);
        }
        //____________________________________________________________________________________________________________
        public double[] multiply(double[] a, double[] b)
        {
            double[] result = new double[16];
            result[0] = (a[0] * b[0]) + (a[4] * b[1]) + (a[8] * b[2]) + (a[12] * b[3]);
            result[1] = (a[1] * b[0]) + (a[5] * b[1]) + (a[9] * b[2]) + (a[13] * b[3]);
            result[2] = (a[2] * b[0]) + (a[6] * b[1]) + (a[10] * b[2]) + (a[14] * b[3]);
            result[3] = (a[3] * b[0]) + (a[7] * b[1]) + (a[11] * b[2]) + (a[15] * b[3]);

            result[4] = (a[0] * b[4]) + (a[4] * b[5]) + (a[8] * b[6]) + (a[12] * b[7]);
            result[5] = (a[1] * b[4]) + (a[5] * b[5]) + (a[9] * b[6]) + (a[13] * b[7]);
            result[6] = (a[2] * b[4]) + (a[6] * b[5]) + (a[10] * b[6]) + (a[14] * b[7]);
            result[7] = (a[3] * b[4]) + (a[7] * b[5]) + (a[11] * b[6]) + (a[15] * b[7]);

            result[8] = (a[0] * b[8]) + (a[4] * b[9]) + (a[8] * b[10]) + (a[12] * b[11]);
            result[9] = (a[1] * b[8]) + (a[5] * b[9]) + (a[9] * b[10]) + (a[13] * b[11]);
            result[10] = (a[2] * b[8]) + (a[6] * b[9]) + (a[10] * b[10]) + (a[14] * b[11]);
            result[11] = (a[3] * b[8]) + (a[7] * b[9]) + (a[11] * b[10]) + (a[15] * b[11]);

            result[12] = (a[0] * b[12]) + (a[4] * b[13]) + (a[8] * b[14]) + (a[12] * b[15]);
            result[13] = (a[1] * b[12]) + (a[5] * b[13]) + (a[9] * b[14]) + (a[13] * b[15]);
            result[14] = (a[2] * b[12]) + (a[6] * b[13]) + (a[10] * b[14]) + (a[14] * b[15]);
            result[15] = (a[3] * b[12]) + (a[7] * b[13]) + (a[11] * b[14]) + (a[15] * b[15]);
            return result;
        }
        //____________________________________________________________________________________________________________
        public double[] multiply_3x3(double[] a, double[] b)
        {
            double[] result = new double[9];
            result[0] = (a[0] * b[0]) + (a[3] * b[1]) + (a[6] * b[2]);
            result[1] = (a[1] * b[0]) + (a[4] * b[1]) + (a[7] * b[2]);
            result[2] = (a[2] * b[0]) + (a[5] * b[1]) + (a[8] * b[2]);

            result[3] = (a[0] * b[4]) + (a[3] * b[5]) + (a[6] * b[6]);
            result[4] = (a[1] * b[4]) + (a[4] * b[5]) + (a[7] * b[6]);
            result[5] = (a[2] * b[4]) + (a[5] * b[5]) + (a[8] * b[6]);

            result[6] = (a[0] * b[8]) + (a[3] * b[9]) + (a[6] * b[10]);
            result[7] = (a[1] * b[8]) + (a[4] * b[9]) + (a[7] * b[10]);
            result[8] = (a[2] * b[8]) + (a[5] * b[9]) + (a[8] * b[10]);

            return result;
        }
        //____________________________________________________________________________________________________________

    }// class
}// ns






///////////////////////////////////////////////////////////////
//double[] TF = new double[16];
//double X, Y, Z, rx, ry, rz;
//X = Y = Z = rx = ry = rz = 0;

//TF[0] = Math.Cos(helper.ToRadians(rz)) * Math.Cos(helper.ToRadians(ry));
//TF[1] = Math.Sin(helper.ToRadians(rz)) * Math.Cos(helper.ToRadians(ry));
//TF[2] = -Math.Sin(helper.ToRadians(rz));
//TF[3] = 0;

//TF[4] = -Math.Sin(helper.ToRadians(rz)) * Math.Cos(helper.ToRadians(rx)) + Math.Cos(helper.ToRadians(rz)) * Math.Sin(helper.ToRadians(ry)) * Math.Sin(helper.ToRadians(rx));
//TF[5] = Math.Cos(helper.ToRadians(rz)) * Math.Cos(helper.ToRadians(rx)) + Math.Sin(helper.ToRadians(rz)) * Math.Sin(helper.ToRadians(ry)) * Math.Sin(helper.ToRadians(rx));
//TF[6] = Math.Cos(helper.ToRadians(ry)) * Math.Sin(helper.ToRadians(rx));
//TF[7] = 0;

//TF[8] = Math.Sin(helper.ToRadians(rz)) * Math.Sin(helper.ToRadians(rx)) + Math.Cos(helper.ToRadians(rz)) * Math.Sin(helper.ToRadians(ry)) * Math.Cos(helper.ToRadians(rx));
//TF[9] =-Math.Cos(helper.ToRadians(rz)) * Math.Sin(helper.ToRadians(rx)) + Math.Sin(helper.ToRadians(rz)) * Math.Sin(helper.ToRadians(ry)) * Math.Cos(helper.ToRadians(rx));
//TF[10] = Math.Cos(helper.ToRadians(ry)) * Math.Cos(helper.ToRadians(rx));
//TF[11] = 0;

//TF[12] = -(X);
//TF[13] = -(Y);
//TF[14] = -(Z);
//TF[15] = 1;

//   frm_matrix mtx3 = new frm_matrix(R06, "R06 Matrix");
///////////////////////////////////////////////////////////////
//  double[] TF = helper.Get_Identity();// new double[16];











//  double[] WFM = new double[16];

//double H13, H14, H15, H16, H17, H18;
//H13 = H14 = H15 = H16 = H17 = H18 = 0;

//WFM[0] = Math.Cos(helper.ToRadians(H18)) * Math.Cos(helper.ToRadians(H17));
//WFM[1] = Math.Sin(helper.ToRadians(H18)) * Math.Cos(helper.ToRadians(H17));
//WFM[2] = -Math.Sin(helper.ToRadians(H18));
//WFM[3] = 0;

//WFM[4] = -Math.Sin(helper.ToRadians(H18)) * Math.Cos(helper.ToRadians(H16)) + Math.Cos(helper.ToRadians(H18)) * Math.Sin(helper.ToRadians(H17)) * Math.Sin(helper.ToRadians(H16));
//WFM[5] = Math.Cos(helper.ToRadians(H18)) * Math.Cos(helper.ToRadians(H16)) + Math.Sin(helper.ToRadians(H18)) * Math.Sin(helper.ToRadians(H17)) * Math.Sin(helper.ToRadians(H16));
//WFM[6] = Math.Cos(helper.ToRadians(H17)) * Math.Sin(helper.ToRadians(H16));
//WFM[7] = 0;

//WFM[8] = Math.Sin(helper.ToRadians(H18)) * Math.Sin(helper.ToRadians(H16)) + Math.Cos(helper.ToRadians(H18)) * Math.Sin(helper.ToRadians(H17)) * Math.Cos(helper.ToRadians(H16));
//WFM[9] = -Math.Cos(helper.ToRadians(H18)) * Math.Sin(helper.ToRadians(H16)) + Math.Sin(helper.ToRadians(H18)) * Math.Sin(helper.ToRadians(H17)) * Math.Cos(helper.ToRadians(H16));
//WFM[10] = Math.Cos(helper.ToRadians(H17)) * Math.Cos(helper.ToRadians(H16));
//WFM[11] = 0;

//WFM[12] = H13;
//WFM[13] = H14;
//WFM[14] = H15;
//WFM[15] = 1;
/////////////////////////////////




//R01[0] = (WFM[0] * J1[0]) + (WFM[4] * J1[1]) + (J1[9] * J1[2]) + (WFM[12] * J1[3]);
//R01[1] = (WFM[1] * J1[0]) + (WFM[5] * J1[1]) + (WFM[9] * J1[2]) + (WFM[13] * J1[3]);
//R01[2] = (WFM[2] * J1[0]) + (WFM[6] * J1[1]) + (WFM[10] * J1[2]) + (WFM[14] * J1[3]);
//R01[3] = (WFM[3] * J1[0]) + (WFM[7] * J1[1]) + (WFM[11] * J1[2]) + (WFM[15] * J1[3]);

//R01[4] = (WFM[0] * J1[4]) + (WFM[4] * J1[5]) + (WFM[8] * J1[6]) + (WFM[12] * J1[7]);
//R01[5] = (WFM[1] * J1[4]) + (WFM[5] * J1[5]) + (WFM[9] * J1[6]) + (WFM[13] * J1[7]);
//R01[6] = (WFM[2] * J1[4]) + (WFM[6] * J1[5]) + (WFM[10] * J1[6]) + (WFM[14] * J1[7]);
//R01[7] = (WFM[3] * J1[4]) + (WFM[7] * J1[5]) + (WFM[11] * J1[6]) + (WFM[15] * J1[7]);

//R01[8] = (WFM[0] * J1[8]) + (WFM[4] * J1[9]) + (WFM[8] * J1[10]) + (WFM[12] * J1[11]);
//R01[9] = (WFM[1] * J1[8]) + (WFM[5] * J1[9]) + (WFM[9] * J1[10]) + (WFM[13] * J1[11]);
//R01[10] = (WFM[2] * J1[8]) + (WFM[6] * J1[9]) + (WFM[10] * J1[10]) + (WFM[14] * J1[11]);
//R01[11] = (WFM[3] * J1[8]) + (WFM[7] * J1[9]) + (WFM[11] * J1[10]) + (WFM[15] * J1[11]);

//R01[12] = (WFM[0] * J1[12]) + (WFM[4] * J1[13]) + (WFM[8] * J1[14]) + (WFM[12] * J1[15]);
//R01[13] = (WFM[1] * J1[12]) + (WFM[5] * J1[13]) + (WFM[9] * J1[14]) + (WFM[13] * J1[15]);
//R01[14] = (WFM[2] * J1[12]) + (WFM[6] * J1[13]) + (WFM[10] * J1[14]) + (WFM[14] * J1[15]);
//R01[15] = (WFM[3] * J1[12]) + (WFM[7] * J1[13]) + (WFM[11] * J1[14]) + (WFM[15] * J1[15]);

//   frm_matrix md = new frm_matrix(R01, "R01 Matrix");

//    frm_matrix md = new frm_matrix(R01, "test");


///////////////////////////////////////////////////////////////
//double[] R02 = new double[16];
//double[] J2 = Get_matrix(dh[1]);

//R02[0] = (R01[0] * J2[0]) + (R01[4] * J2[1]) + (R01[8] * J2[2]) + (R01[12] * J2[3]);
//R02[1] = (R01[1] * J2[0]) + (R01[5] * J2[1]) + (R01[9] * J2[2]) + (R01[13] * J2[3]);
//R02[2] = (R01[2] * J2[0]) + (R01[6] * J2[1]) + (R01[10] * J2[2]) + (R01[14] * J2[3]);
//R02[3] = (R01[3] * J2[0]) + (R01[7] * J2[1]) + (R01[11] * J2[2]) + (R01[15] * J2[3]);

//R02[4] = (R01[0] * J2[4]) + (R01[4] * J2[5]) + (R01[8] * J2[6]) + (R01[12] * J2[7]);
//R02[5] = (R01[1] * J2[4]) + (R01[5] * J2[5]) + (R01[9] * J2[6]) + (R01[13] * J2[7]);
//R02[6] = (R01[2] * J2[4]) + (R01[6] * J2[5]) + (R01[10] * J2[6]) + (R01[14] * J2[7]);
//R02[7] = (R01[3] * J2[4]) + (R01[7] * J2[5]) + (R01[11] * J2[6]) + (R01[15] * J2[7]);

//R02[8] = (R01[0] * J2[8]) + (R01[4] * J2[9]) + (R01[8] * J2[10]) + (R01[12] * J2[11]);
//R02[9] = (R01[1] * J2[8]) + (R01[5] * J2[9]) + (R01[9] * J2[10]) + (R01[13] * J2[11]);
//R02[10] =(R01[2] * J2[8]) + (R01[6] * J2[9]) + (R01[10] * J2[10]) + (R01[14] * J2[11]);
//R02[11] =(R01[3] * J2[8]) + (R01[7] * J2[9]) + (R01[11] * J2[10]) + (R01[15] * J2[11]);

//R02[12] =(R01[0] * J2[12]) + (R01[4] * J2[13]) + (R01[8] * J2[14]) + (R01[12] * J2[15]);
//R02[13] =(R01[1] * J2[12]) + (R01[5] * J2[13]) + (R01[9] * J2[14]) + (R01[13] * J2[15]);
//R02[14] =(R01[2] * J2[12]) + (R01[6] * J2[13]) + (R01[10] * J2[14]) + (R01[14] * J2[15]);
//R02[15] =(R01[3] * J2[12]) + (R01[7] * J2[13]) + (R01[11] * J2[14]) + (R01[15] * J2[15]);

// frm_matrix mtx3 = new frm_matrix(R01, "R01 Matrix");
///////////////////////////////////////////////////////////////
//double[] R03 = new double[16];
//double[] J3 = Get_matrix(dh[2]);
//R03 = multiply(R02, J3);

//R03[0] = (R02[0] * J3[0]) + (R02[4] * J3[1]) + (R02[8] * J3[2]) + (R02[12] * J3[3]);
//R03[1] = (R02[1] * J3[0]) + (R02[5] * J3[1]) + (R02[9] * J3[2]) + (R02[13] * J3[3]);
//R03[2] = (R02[2] * J3[0]) + (R02[6] * J3[1]) + (R02[10] * J3[2]) + (R02[14] * J3[3]);
//R03[3] = (R02[3] * J3[0]) + (R02[7] * J3[1]) + (R02[11] * J3[2]) + (R02[15] * J3[3]);

//R03[4] = (R02[0] * J3[4]) + (R02[4] * J3[5]) + (R02[8] * J3[6]) + (R02[12] * J3[7]);
//R03[5] = (R02[1] * J3[4]) + (R02[5] * J3[5]) + (R02[9] * J3[6]) + (R02[13] * J3[7]);
//R03[6] = (R02[2] * J3[4]) + (R02[6] * J3[5]) + (R02[10] * J3[6]) + (R02[14] * J3[7]);
//R03[7] = (R02[3] * J3[4]) + (R02[7] * J3[5]) + (R02[11] * J3[6]) + (R02[15] * J3[7]);

//R03[8] = (R02[0] * J3[8]) + (R02[4] * J3[9]) + (R02[8] * J3[10]) + (R02[12] * J3[11]);
//R03[9] = (R02[1] * J3[8]) + (R02[5] * J3[9]) + (R02[9] * J3[10]) + (R02[13] * J3[11]);
//R03[10] = (R02[2] * J3[8]) + (R02[6] * J3[9]) + (R02[10] * J3[10]) + (R02[14] * J3[11]);
//R03[11] = (R02[3] * J3[8]) + (R02[7] * J3[9]) + (R02[11] * J3[10]) + (R02[15] * J3[11]);

//R03[12] = (R02[0] * J3[12]) + (R02[4] * J3[13]) + (R02[8] * J3[14]) + (R02[12] * J3[15]);
//R03[13] = (R02[1] * J3[12]) + (R02[5] * J3[13]) + (R02[9] * J3[14]) + (R02[13] * J3[15]);
//R03[14] = (R02[2] * J3[12]) + (R02[6] * J3[13]) + (R02[10] * J3[14]) + (R02[14] * J3[15]);
//R03[15] = (R02[3] * J3[12]) + (R02[7] * J3[13]) + (R02[11] * J3[14]) + (R02[15] * J3[15]);

// frm_matrix mtx3 = new frm_matrix(R01, "R01 Matrix");
///////////////////////////////////////////////////////////////
//double[] R04 = new double[16];
//double[] J4 = Get_matrix(dh[3]);
//R04 = multiply(R03, J4);

//R04[0] = (R03[0] * J4[0]) + (R03[4] * J4[1]) + (R03[8] * J4[2]) + (R03[12] * J4[3]);
//R04[1] = (R03[1] * J4[0]) + (R03[5] * J4[1]) + (R03[9] * J4[2]) + (R03[13] * J4[3]);
//R04[2] = (R03[2] * J4[0]) + (R03[6] * J4[1]) + (R03[10] * J4[2]) + (R03[14] * J4[3]);
//R04[3] = (R03[3] * J4[0]) + (R03[7] * J4[1]) + (R03[11] * J4[2]) + (R03[15] * J4[3]);

//R04[4] = (R03[0] * J4[4]) + (R03[4] * J4[5]) + (R03[8] * J4[6]) + (R03[12] * J4[7]);
//R04[5] = (R03[1] * J4[4]) + (R03[5] * J4[5]) + (R03[9] * J4[6]) + (R03[13] * J4[7]);
//R04[6] = (R03[2] * J4[4]) + (R03[6] * J4[5]) + (R03[10] * J4[6]) + (R03[14] * J4[7]);
//R04[7] = (R03[3] * J4[4]) + (R03[7] * J4[5]) + (R03[11] * J4[6]) + (R03[15] * J4[7]);

//R04[8] = (R03[0] * J4[8]) + (R03[4] * J4[9]) + (R03[8] * J4[10]) + (R03[12] * J4[11]);
//R04[9] = (R03[1] * J4[8]) + (R03[5] * J4[9]) + (R03[9] * J4[10]) + (R03[13] * J4[11]);
//R04[10] = (R03[2] * J4[8]) + (R03[6] * J4[9]) + (R03[10] * J4[10]) + (R03[14] * J4[11]);
//R04[11] = (R03[3] * J4[8]) + (R03[7] * J4[9]) + (R03[11] * J4[10]) + (R03[15] * J4[11]);

//R04[12] = (R03[0] * J4[12]) + (R03[4] * J4[13]) + (R03[8] * J4[14]) + (R03[12] * J4[15]);
//R04[13] = (R03[1] * J4[12]) + (R03[5] * J4[13]) + (R03[9] * J4[14]) + (R03[13] * J4[15]);
//R04[14] = (R03[2] * J4[12]) + (R03[6] * J4[13]) + (R03[10] * J4[14]) + (R03[14] * J4[15]);
//R04[15] = (R03[3] * J4[12]) + (R03[7] * J4[13]) + (R03[11] * J4[14]) + (R03[15] * J4[15]);

// frm_matrix mtx3 = new frm_matrix(R01, "R01 Matrix");
///////////////////////////////////////////////////////////////
//double[] R05 = new double[16];
//double[] J5 = Get_matrix(dh[4]);
//R05 = multiply(R04, J5);

//R05[0] = (R04[0] * J5[0]) + (R04[4] * J5[1]) + (R04[8] * J5[2]) + (R04[12] * J5[3]);
//R05[1] = (R04[1] * J5[0]) + (R04[5] * J5[1]) + (R04[9] * J5[2]) + (R04[13] * J5[3]);
//R05[2] = (R04[2] * J5[0]) + (R04[6] * J5[1]) + (R04[10] * J5[2]) + (R04[14] * J5[3]);
//R05[3] = (R04[3] * J5[0]) + (R04[7] * J5[1]) + (R04[11] * J5[2]) + (R04[15] * J5[3]);

//R05[4] = (R04[0] * J5[4]) + (R04[4] * J5[5]) + (R04[8] * J5[6]) + (R04[12] * J5[7]);
//R05[5] = (R04[1] * J5[4]) + (R04[5] * J5[5]) + (R04[9] * J5[6]) + (R04[13] * J5[7]);
//R05[6] = (R04[2] * J5[4]) + (R04[6] * J5[5]) + (R04[10] * J5[6]) + (R04[14] * J5[7]);
//R05[7] = (R04[3] * J5[4]) + (R04[7] * J5[5]) + (R04[11] * J5[6]) + (R04[15] * J5[7]);

//R05[8] = (R04[0] * J5[8]) + (R04[4] * J5[9]) + (R04[8] * J5[10]) + (R04[12] * J5[11]);
//R05[9] = (R04[1] * J5[8]) + (R04[5] * J5[9]) + (R04[9] * J5[10]) + (R04[13] * J5[11]);
//R05[10] = (R04[2] * J5[8]) + (R04[6] * J5[9]) + (R04[10] * J5[10]) + (R04[14] * J5[11]);
//R05[11] = (R04[3] * J5[8]) + (R04[7] * J5[9]) + (R04[11] * J5[10]) + (R04[15] * J5[11]);

//R05[12] = (R04[0] * J5[12]) + (R04[4] * J5[13]) + (R04[8] * J5[14]) + (R04[12] * J5[15]);
//R05[13] = (R04[1] * J5[12]) + (R04[5] * J5[13]) + (R04[9] * J5[14]) + (R04[13] * J5[15]);
//R05[14] = (R04[2] * J5[12]) + (R04[6] * J5[13]) + (R04[10] * J5[14]) + (R04[14] * J5[15]);
//R05[15] = (R04[3] * J5[12]) + (R04[7] * J5[13]) + (R04[11] * J5[14]) + (R04[15] * J5[15]);

// frm_matrix mtx3 = new frm_matrix(R01, "R01 Matrix");
///////////////////////////////////////////////////////////////
//double[] R06 = new double[16];
//double[] J6 = Get_matrix(dh[5]);

//R06 = multiply(R05, J6);

//R06[0] = (R05[0] * J6[0]) + (R05[4] * J6[1]) + (R05[8] * J6[2]) + (R05[12] * J6[3]);
//R06[1] = (R05[1] * J6[0]) + (R05[5] * J6[1]) + (R05[9] * J6[2]) + (R05[13] * J6[3]);
//R06[2] = (R05[2] * J6[0]) + (R05[6] * J6[1]) + (R05[10] * J6[2]) + (R05[14] * J6[3]);
//R06[3] = (R05[3] * J6[0]) + (R05[7] * J6[1]) + (R05[11] * J6[2]) + (R05[15] * J6[3]);

//R06[4] = (R05[0] * J6[4]) + (R05[4] * J6[5]) + (R05[8] * J6[6]) + (R05[12] * J6[7]);
//R06[5] = (R05[1] * J6[4]) + (R05[5] * J6[5]) + (R05[9] * J6[6]) + (R05[13] * J6[7]);
//R06[6] = (R05[2] * J6[4]) + (R05[6] * J6[5]) + (R05[10] * J6[6]) + (R05[14] * J6[7]);
//R06[7] = (R05[3] * J6[4]) + (R05[7] * J6[5]) + (R05[11] * J6[6]) + (R05[15] * J6[7]);

//R06[8] = (R05[0] * J6[8]) + (R05[4] * J6[9]) + (R05[8] * J6[10]) + (R05[12] * J6[11]);
//R06[9] = (R05[1] * J6[8]) + (R05[5] * J6[9]) + (R05[9] * J6[10]) + (R05[13] * J6[11]);
//R06[10] = (R05[2] * J6[8]) + (R05[6] * J6[9]) + (R05[10] * J6[10]) + (R05[14] * J6[11]);
//R06[11] = (R05[3] * J6[8]) + (R05[7] * J6[9]) + (R05[11] * J6[10]) + (R05[15] * J6[11]);

//R06[12] = (R05[0] * J6[12]) + (R05[4] * J6[13]) + (R05[8] * J6[14]) + (R05[12] * J6[15]);
//R06[13] = (R05[1] * J6[12]) + (R05[5] * J6[13]) + (R05[9] * J6[14]) + (R05[13] * J6[15]);
//R06[14] = (R05[2] * J6[12]) + (R05[6] * J6[13]) + (R05[10] * J6[14]) + (R05[14] * J6[15]);
//R06[15] = (R05[3] * J6[12]) + (R05[7] * J6[13]) + (R05[11] * J6[14]) + (R05[15] * J6[15]);

//  frm_matrix mtx3 = new frm_matrix(R06, "R06 Matrix");



//R0T[0] = (R06[0] * TF[0]) + (R06[4] * TF[1]) + (R06[8] * TF[2]) + (R06[12] * TF[3]);
//R0T[1] = (R06[1] * TF[0]) + (R06[5] * TF[1]) + (R06[9] * TF[2]) + (R06[13] * TF[3]);
//R0T[2] = (R06[2] * TF[0]) + (R06[6] * TF[1]) + (R06[10]* TF[2]) + (R06[14] * TF[3]);
//R0T[3] = (R06[3] * TF[0]) + (R06[7] * TF[1]) + (R06[11]* TF[2]) + (R06[15] * TF[3]);

//R0T[4] = (R06[0] * TF[4]) + (R06[4] * TF[5]) + (R06[8] * TF[6]) + (R06[12] * TF[7]);
//R0T[5] = (R06[1] * TF[4]) + (R06[5] * TF[5]) + (R06[9] * TF[6]) + (R06[13] * TF[7]);
//R0T[6] = (R06[2] * TF[4]) + (R06[6] * TF[5]) + (R06[10]* TF[6]) + (R06[14] * TF[7]);
//R0T[7] = (R06[3] * TF[4]) + (R06[7] * TF[5]) + (R06[11]* TF[6]) + (R06[15] * TF[7]);

//R0T[8] = (R06[0] * TF[8]) + (R06[4] * TF[9]) + (R06[8] * TF[10]) + (R06[12] * TF[11]);
//R0T[9] = (R06[1] * TF[8]) + (R06[5] * TF[9]) + (R06[9] * TF[10]) + (R06[13] * TF[11]);
//R0T[10] =(R06[2] * TF[8]) + (R06[6] * TF[9]) + (R06[10]* TF[10]) + (R06[14] * TF[11]);
//R0T[11] =(R06[3] * TF[8]) + (R06[7] * TF[9]) + (R06[11]* TF[10]) + (R06[15] * TF[11]);

//R0T[12]= (R06[0] * TF[12]) + (R06[4] * TF[13]) + (R06[8] * TF[14]) + (R06[12] * TF[15]);
//R0T[13]= (R06[1] * TF[12]) + (R06[5] * TF[13]) + (R06[9] * TF[14]) + (R06[13] * TF[15]);
//R0T[14]= (R06[2] * TF[12]) + (R06[6] * TF[13]) + (R06[10]* TF[14]) + (R06[14] * TF[15]);
//R0T[15]= (R06[3] * TF[12]) + (R06[7] * TF[13]) + (R06[11]* TF[14]) + (R06[15] * TF[15]);

// frm_matrix mtx3 = new frm_matrix(R06, "R06 Matrix");

















//R06[0] = (R0T[0] * ITF[0]) + (R0T[4] * ITF[1]) + (R0T[8] * ITF[2]) + (R0T[12] * ITF[3]);
//R06[1] = (R0T[1] * ITF[0])+(R0T[5] * ITF[1])+(R0T[9] * ITF[2])+(R0T[13] * ITF[3]);
//R06[2] = (R0T[2] * ITF[0])+(R0T[6] * ITF[1])+(R0T[10] * ITF[2])+(R0T[14] * ITF[3]);
//R06[3] = (R0T[3] * ITF[0])+(R0T[7] * ITF[1])+(R0T[11] * ITF[2])+(R0T[15] * ITF[3]);

//R06[4] = (R0T[0] * ITF[4]) + (R0T[4] * ITF[5]) + (R0T[8] * ITF[6]) + (R0T[12] * ITF[7]);
//R06[5] = (R0T[1] * ITF[4]) + (R0T[5] * ITF[5]) + (R0T[9] * ITF[6]) + (R0T[13] * ITF[7]);
//R06[6] = (R0T[2] * ITF[4]) + (R0T[6] * ITF[5]) + (R0T[10] * ITF[6]) + (R0T[14] * ITF[7]);
//R06[7] = (R0T[3] * ITF[4]) + (R0T[7] * ITF[5]) + (R0T[11] * ITF[6]) + (R0T[15] * ITF[7]);

//R06[8] = (R0T[0] * ITF[8]) + (R0T[4] * ITF[9]) + (R0T[8] * ITF[10]) + (R0T[12] * ITF[11]);
//R06[9] = (R0T[1] * ITF[8]) + (R0T[5] * ITF[9]) + (R0T[9] * ITF[10]) + (R0T[13] * ITF[11]);
//R06[10]= (R0T[2] * ITF[8]) + (R0T[6] * ITF[9]) + (R0T[10] * ITF[10]) + (R0T[14] * ITF[11]);
//R06[11]= (R0T[3] * ITF[8]) + (R0T[7] * ITF[9]) + (R0T[11] * ITF[10]) + (R0T[15] * ITF[11]);

//R06[12] = (R0T[0] * ITF[12]) + (R0T[4] * ITF[13]) + (R0T[8] * ITF[14]) + (R0T[12] * ITF[15]);
//R06[13] = (R0T[1] * ITF[12]) + (R0T[5] * ITF[13]) + (R0T[9] * ITF[14]) + (R0T[12] * ITF[15]);
//R06[14] = (R0T[2] * ITF[12]) + (R0T[6] * ITF[13]) + (R0T[10] * ITF[14]) + (R0T[14] * ITF[15]);
//R06[15] = (R0T[3] * ITF[12]) + (R0T[7] * ITF[13]) + (R0T[11] * ITF[14]) + (R0T[15] * ITF[15]);
///////////////////////////////////////////////////////////////////

//R05[0] = (R06[0] * RR06[0]) + (R06[4] * RR06[1]) + (R06[8] * RR06[2]) + (R06[12] * RR06[3]);
//R05[1] = (R06[1] * RR06[0]) + (R06[5] * RR06[1]) + (R06[9] * RR06[2]) + (R06[13] * RR06[3]);
//R05[2] = (R06[2] * RR06[0]) + (R06[6] * RR06[1]) + (R06[10] * RR06[2]) + (R06[14] * RR06[3]);
//R05[3] = (R06[3] * RR06[0]) + (R06[7] * RR06[1]) + (R06[11] * RR06[2]) + (R06[15] * RR06[3]);

//R05[4] = (R06[0] * RR06[4]) + (R06[4] * RR06[5]) + (R06[8] * RR06[6]) + (R06[12] * RR06[7]);
//R05[5] = (R06[1] * RR06[4]) + (R06[5] * RR06[5]) + (R06[9] * RR06[6]) + (R06[13] * RR06[7]);
//R05[6] = (R06[2] * RR06[4]) + (R06[6] * RR06[5]) + (R06[10] * RR06[6]) + (R06[14] * RR06[7]);
//R05[7] = (R06[3] * RR06[4]) + (R06[7] * RR06[5]) + (R06[11] * RR06[6]) + (R06[15] * RR06[7]);

//R05[8] = (R06[0] * RR06[8]) + (R06[4] * RR06[9]) + (R06[8] * RR06[10]) + (R06[12] * RR06[11]);
//R05[9] = (R06[1] * RR06[8]) + (R06[5] * RR06[9]) + (R06[9] * RR06[10]) + (R06[13] * RR06[11]);
//R05[10] = (R06[2] * RR06[8]) + (R06[6] * RR06[9]) + (R06[10] * RR06[10]) + (R06[14] * RR06[11]);
//R05[11] = (R06[3] * RR06[8]) + (R06[7] * RR06[9]) + (R06[11] * RR06[10]) + (R06[15] * RR06[11]);

//R05[12] = (R06[0] * RR06[12]) + (R06[4] * RR06[13]) + (R06[8] * RR06[14]) + (R06[12] * RR06[15]);
//R05[13] = (R06[1] * RR06[12]) + (R06[5] * RR06[13]) + (R06[9] * RR06[14]) + (R06[13] * RR06[15]);
//R05[14] = (R06[2] * RR06[12]) + (R06[6] * RR06[13]) + (R06[10] * RR06[14]) + (R06[14] * RR06[15]);
//R05[15] = (R06[3] * RR06[12]) + (R06[7] * RR06[13]) + (R06[11] * RR06[14]) + (R06[15] * RR06[15]);
/////////////////////////////////////////////////////////////////// 

//R01[0] = (WF[0] * J1[0]) + (WF[4] * J1[1]) + (WF[8] * J1[2]) + (WF[12] * J1[3]);
//R01[1] = (WF[1] * J1[0]) + (WF[5] * J1[1]) + (WF[9] * J1[2]) + (WF[13] * J1[3]);
//R01[2] = (WF[2] * J1[0]) + (WF[6] * J1[1]) + (WF[10] * J1[2]) + (WF[14] * J1[3]);
//R01[3] = (WF[3] * J1[0]) + (WF[7] * J1[1]) + (WF[11] * J1[2]) + (WF[15] * J1[3]);

//R01[4] = (WF[0] * J1[4]) + (WF[4] * J1[5]) + (WF[8] * J1[6]) + (WF[12] * J1[7]);
//R01[5] = (WF[1] * J1[4]) + (WF[5] * J1[5]) + (WF[9] * J1[6]) + (WF[13] * J1[7]);
//R01[6] = (WF[2] * J1[4]) + (WF[6] * J1[5]) + (WF[10] * J1[6]) + (WF[14] * J1[7]);
//R01[7] = (WF[3] * J1[4]) + (WF[7] * J1[5]) + (WF[11] * J1[6]) + (WF[15] * J1[7]);

//R01[8] = (WF[0] * J1[8]) + (WF[4] * J1[9]) + (WF[8] * J1[10]) + (WF[12] * J1[11]);
//R01[9] = (WF[1] * J1[8]) + (WF[5] * J1[9]) + (WF[9] * J1[10]) + (WF[13] * J1[11]);
//R01[10] = (WF[2] * J1[8]) + (WF[6] * J1[9]) + (WF[10] * J1[10]) + (WF[14] * J1[11]);
//R01[11] = (WF[3] * J1[8]) + (WF[7] * J1[9]) + (WF[11] * J1[10]) + (WF[15] * J1[11]);

//R01[12] = (WF[0] * J1[12]) + (WF[4] * J1[13]) + (WF[8] * J1[14]) + (WF[12] * J1[15]);
//R01[13] = (WF[1] * J1[12]) + (WF[5] * J1[13]) + (WF[9] * J1[14]) + (WF[13] * J1[15]);
//R01[14] = (WF[2] * J1[12]) + (WF[6] * J1[13]) + (WF[10] * J1[14]) + (WF[14] * J1[15]);
//R01[15] = (WF[3] * J1[12]) + (WF[7] * J1[13]) + (WF[11] * J1[14]) + (WF[15] * J1[15]);

//R02[0] = (R01[0] * J2[0]) + (R01[4] * J2[1]) + (R01[8] * J2[2]) + (R01[12] * J2[3]);
//R02[1] = (R01[1] * J2[0]) + (R01[5] * J2[1]) + (R01[9] * J2[2]) + (R01[13] * J2[3]);
//R02[2] = (R01[2] * J2[0]) + (R01[6] * J2[1]) + (R01[10] * J2[2]) + (R01[14] * J2[3]);
//R02[3] = (R01[3] * J2[0]) + (R01[7] * J2[1]) + (R01[11] * J2[2]) + (R01[15] * J2[3]);

//R02[4] = (R01[0] * J2[4]) + (R01[4] * J2[5]) + (R01[8] * J2[6]) + (R01[12] * J2[7]);
//R02[5] = (R01[1] * J2[4]) + (R01[5] * J2[5]) + (R01[9] * J2[6]) + (R01[13] * J2[7]);
//R02[6] = (R01[2] * J2[4]) + (R01[6] * J2[5]) + (R01[10] * J2[6]) + (R01[14] * J2[7]);
//R02[7] = (R01[3] * J2[4]) + (R01[7] * J2[5]) + (R01[11] * J2[6]) + (R01[15] * J2[7]);

//R02[8] = (R01[0] * J2[8]) + (R01[4] * J2[9]) + (R01[8] * J2[10]) + (R01[12] * J2[11]);
//R02[9] = (R01[1] * J2[8]) + (R01[5] * J2[9]) + (R01[9] * J2[10]) + (R01[13] * J2[11]);
//R02[10]= (R01[2] * J2[8]) + (R01[6] * J2[9]) + (R01[10] * J2[10]) + (R01[14] * J2[11]);
//R02[11]= (R01[3] * J2[8]) + (R01[7] * J2[9]) + (R01[11] * J2[10]) + (R01[15] * J2[11]);

//R02[12]= (R01[0] * J2[12]) + (R01[4] * J2[13]) + (R01[8] * J2[14]) + (R01[12] * J2[15]);
//R02[13]= (R01[1] * J2[12]) + (R01[5] * J2[13]) + (R01[9] * J2[14]) + (R01[13] * J2[15]);
//R02[14]= (R01[2] * J2[12]) + (R01[6] * J2[13]) + (R01[10] * J2[14]) + (R01[14] * J2[15]);
//R02[15]= (R01[3] * J2[12]) + (R01[7] * J2[13]) + (R01[11] * J2[14]) + (R01[15] * J2[15]);
///////////////////////////////////////////////////////////////////

//R03[0] = (R02[0] * J3[0]) + (R02[4] * J3[1]) + (R02[8] * J3[2]) + (R02[12] * J3[3]);
//R03[1] = (R02[1] * J3[0]) + (R02[5] * J3[1]) + (R02[9] * J3[2]) + (R02[13] * J3[3]);
//R03[2] = (R02[2] * J3[0]) + (R02[6] * J3[1]) + (R02[10] * J3[2]) + (R02[14] * J3[3]);
//R03[3] = (R02[3] * J3[0]) + (R02[7] * J3[1]) + (R02[11] * J3[2]) + (R02[15] * J3[3]);

//R03[4] = (R02[0] * J3[4]) + (R02[4] * J3[5]) + (R02[8] * J3[6]) + (R02[12] * J3[7]);
//R03[5] = (R02[1] * J3[4]) + (R02[5] * J3[5]) + (R02[9] * J3[6]) + (R02[13] * J3[7]);
//R03[6] = (R02[2] * J3[4]) + (R02[6] * J3[5]) + (R02[10] * J3[6]) + (R02[14] * J3[7]);
//R03[7] = (R02[3] * J3[4]) + (R02[7] * J3[5]) + (R02[11] * J3[6]) + (R02[15] * J3[7]);

//R03[8] = (R02[0] * J3[8]) + (R02[4] * J3[9]) + (R02[8] * J3[10]) + (R02[12] * J3[11]);
//R03[9] = (R02[1] * J3[8]) + (R02[5] * J3[9]) + (R02[9] * J3[10]) + (R02[13] * J3[11]);
//R03[10] = (R02[2] * J3[8]) + (R02[6] * J3[9]) + (R02[10] * J3[10]) + (R02[14] * J3[11]);
//R03[11] = (R02[3] * J3[8]) + (R02[7] * J3[9]) + (R02[11] * J3[10]) + (R02[15] * J3[11]);

//R03[12] = (R02[0] * J3[12]) + (R02[4] * J3[13]) + (R02[8] * J3[14]) + (R02[12] * J3[15]);
//R03[13] = (R02[1] * J3[12]) + (R02[5] * J3[13]) + (R02[9] * J3[14]) + (R02[13] * J3[15]);
//R03[14] = (R02[2] * J3[12]) + (R02[6] * J3[13]) + (R02[10] * J3[14]) + (R02[14] * J3[15]);
//R03[15] = (R02[3] * J3[12]) + (R02[7] * J3[13]) + (R02[11] * J3[14]) + (R02[15] * J3[15]);
///////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////


//double[] R0T_offset = new double[16];

//R0T_offset[0] = ((N30* X$30)+(O30* X$31)+(P30* X$32)+(Q30* X$33))*-1;
//            R0T_offset[1] = (N31* X$30)+(O31* X$31)+(P31* X$32)+(Q31* X$33);
//            R0T_offset[2] = (N32* X$30)+(O32* X$31)+(P32* X$32)+(Q32* X$33);
//            R0T_offset[3] = (N33* X$30)+(O33* X$31)+(P33* X$32)+(Q33* X$33);

//            R0T_offset[4] = (N30* Y$30)+(O30* Y$31)+(P30* Y$32)+(Q30* Y$33);
//            R0T_offset[5] = (N31* Y$30)+(O31* Y$31)+(P31* Y$32)+(Q31* Y$33);
//            R0T_offset[6] = (N32* Y$30)+(O32* Y$31)+(P32* Y$32)+(Q32* Y$33);
//            R0T_offset[7] = (N33* Y$30)+(O33* Y$31)+(P33* Y$32)+(Q33* Y$33);

//            R0T_offset[8] = (N30* Z$30)+(O30* Z$31)+(P30* Z$32)+(Q30* Z$33);
//            R0T_offset[9] = (N31* Z$30)+(O31* Z$31)+(P31* Z$32)+(Q31* Z$33);
//            R0T_offset[10] = (N32* Z$30)+(O32* Z$31)+(P32* Z$32)+(Q32* Z$33);
//            R0T_offset[11] = (N33* Z$30)+(O33* Z$31)+(P33* Z$32)+(Q33* Z$33);

//            R0T_offset[12] = (N30* AA$30)+(O30* AA$31)+(P30* AA$32)+(Q30* AA$33);
//            R0T_offset[13] = (N31* AA$30)+(O31* AA$31)+(P31* AA$32)+(Q31* AA$33);
//            R0T_offset[14] = (N32* AA$30)+(O32* AA$31)+(P32* AA$32)+(Q32* AA$33);
//            R0T_offset[15] = (N33* AA$30)+(O33* AA$31)+(P33* AA$32)+(Q33* AA$33);







//  List<string> angle = new List<string>();

//double[] j1 = new float[16];
//double[] j2 = new float[16];
//double[] j3 = new float[16];
//float[] j4 = new float[16];
//float[] j5 = new float[16];
//float[] j6 = new float[16];

//float[] EF = new float[16];

//j1=  Get_matrix(dh[0]);
//j2 = Get_matrix(dh[1]);
//j3 = Get_matrix(dh[2]);
//j4 = Get_matrix(dh[3]);
//j5 = Get_matrix(dh[4]);
//j6 = Get_matrix(dh[5]);

//gl.PushMatrix();
//gl.LoadIdentity();

//gl.MultMatrix(j1);
//gl.MultMatrix(j2);
//gl.MultMatrix(j3);
//gl.MultMatrix(j4);
//gl.MultMatrix(j5);
//gl.MultMatrix(j6);

//gl.GetFloat(OpenGL.GL_MODELVIEW_MATRIX, EF);
//gl.PopMatrix();