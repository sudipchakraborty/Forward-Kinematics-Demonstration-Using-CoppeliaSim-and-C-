﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Tools
{
    class CoppeliaBlueRobot
    {
        Thread loop;
        bool exit = false;
        int FSM;
        bool connected = false;
        bool received = false;
        public string bfr_TX = "";
        public string bfr_RX = "";
        double counter = 0;

        tcp_client client;
        public string ip_address = "127.0.0.1";
        public int port = 6000;
        public string strEcho = "";


        /// <summary>
        /// robot state handler
        /// </summary>
        //enum rbt_state
        //{
        //    FSM_Init,
        //    FSM_Idle,
        //    FSM_send_data,
        //    FSM_Read_Data
        //};
        //____________________________________________________________________________
        public CoppeliaBlueRobot()
        {

        }
        //___________________________________________________________________________
        public void start()
        {
            loop = new Thread(Robot_Handle);
            loop.Start();
        }
        //__________________________________________________________________________
        public void stop()
        {
            exit = true;
        }
        //___________________________________________________________________________
        private void Robot_Handle()
        {
            while(!exit)
            {
                Thread.Sleep(1);

                if(bfr_TX != "") 
                { 

                client = new tcp_client(ip_address,port);
                client.connect();

                    if (client.connected)
                    {
                        connected = true;
                        byte[] dst_bfr = new byte[100];
                        byte[] b = null;

                        //if (bfr_TX == "")
                        //{
                        //    b = Encoding.ASCII.GetBytes("IDLE COUNT=" + counter.ToString() + "\r\n");
                        //}
                        //else
                        //{
                        b = Encoding.ASCII.GetBytes(bfr_TX + "\r\n");
                        //}
                        client.Data_Received(b, dst_bfr);

                        //if(bfr_TX =="")
                        //{
                        //    counter++;
                        //    strEcho= Encoding.ASCII.GetString(dst_bfr);
                        //}
                        //else
                        //{
                        bfr_TX = "";
                        bfr_RX = Encoding.ASCII.GetString(dst_bfr);
                        received = true;
                        // }                  
                        client.close();
                    }
                }
                else
                {
                    connected = false;
                }

                //        break;
                //    //////////////////////////////////////////
                //    case (int)rbt_state.FSM_Idle:
                //        if(bfr_TX !="")
                //        {
                //            FSM = (int)rbt_state.FSM_send_data;
                //        }
                //        else
                //        {
                //            byte[] dst_bfr = new byte[100];
                //            byte[] b = Encoding.ASCII.GetBytes("IDLE COUNT="+counter.ToString()+"\r\n");
                //            client.Data_Received(b, dst_bfr);
                //            counter++;
                //        }
                //        break;
                //    /////////////////////////////////////////
                //    case (int)rbt_state.FSM_send_data:
                //        byte[] dst_bfr2 = new byte[100];
                //        byte[] b1= Encoding.ASCII.GetBytes(bfr_TX);              
                //        client.Data_Received(b1, dst_bfr2);
                //        bfr_RX= Encoding.ASCII.GetString(dst_bfr2);
                //        bfr_TX = "";
                //        FSM = (int)rbt_state.FSM_Idle;
                //        break;        
                //    //////////////////////////////////////////
                //    default: break;
                //}
            }// while
        }
        //________________________________________________________________________
        public void push_FK_Data(string j1,String j2,string j3,string j4,string j5, string j6)
        {
            string s = "";
            s += "J1=" + utilIK.ToRadians(Convert.ToDouble(j1)).ToString()+ ",";
            s += "J2=" + utilIK.ToRadians(Convert.ToDouble(j2)).ToString() + ",";
            s += "J3=" + utilIK.ToRadians(Convert.ToDouble(j3)).ToString() + ",";
            s += "J4=" + utilIK.ToRadians(Convert.ToDouble(j4)).ToString() + ",";
            s += "J5=" + utilIK.ToRadians(Convert.ToDouble(j5)).ToString() + ",";
            s += "J6=" + utilIK.ToRadians(Convert.ToDouble(j6)).ToString();
            bfr_TX = "<FK#" + s + ">";
        }
        //_____________________________________________________________________________________________________
        public void push_IK_Data(string tx, String ty, string tz, string rx, string ry, string rz)
        {
            string s = "";
            s += "TX=" + tx + ",";
            s += "TY=" + ty + ",";
            s += "TZ=" + tz + ",";
            s += "RX=" + rx + ",";
            s += "RY=" + ry + ",";
            s += "RZ=" + rz;
            s = "<IK#" + s + ">";       // <IK#TX=0,TY=0,TZ=0,RX=0,RY=0,RZ=0>
            bfr_TX =s ;
        }
        //_____________________________________________________________________________________________________










    }//class
}//namespace
