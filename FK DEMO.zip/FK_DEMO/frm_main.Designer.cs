﻿
namespace IK_Test
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_msg = new System.Windows.Forms.TextBox();
            this.btn_start = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txt_j6 = new System.Windows.Forms.TextBox();
            this.txt_j5 = new System.Windows.Forms.TextBox();
            this.txt_j4 = new System.Windows.Forms.TextBox();
            this.txt_j3 = new System.Windows.Forms.TextBox();
            this.txt_j2 = new System.Windows.Forms.TextBox();
            this.txt_j1 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.hscroll_J6 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J5 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J4 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J3 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J2 = new System.Windows.Forms.HScrollBar();
            this.hscroll_J1 = new System.Windows.Forms.HScrollBar();
            this.hScroll_RX = new System.Windows.Forms.HScrollBar();
            this.hScroll_TZ = new System.Windows.Forms.HScrollBar();
            this.hScroll_RY = new System.Windows.Forms.HScrollBar();
            this.hScroll_RZ = new System.Windows.Forms.HScrollBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_tx = new System.Windows.Forms.TextBox();
            this.txt_rx = new System.Windows.Forms.TextBox();
            this.txt_ty = new System.Windows.Forms.TextBox();
            this.txt_ry = new System.Windows.Forms.TextBox();
            this.txt_tz = new System.Windows.Forms.TextBox();
            this.txt_rz = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.hScroll_TY = new System.Windows.Forms.HScrollBar();
            this.hScroll_TX = new System.Windows.Forms.HScrollBar();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_msg
            // 
            this.txt_msg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_msg.Location = new System.Drawing.Point(9, 330);
            this.txt_msg.Margin = new System.Windows.Forms.Padding(2);
            this.txt_msg.Name = "txt_msg";
            this.txt_msg.Size = new System.Drawing.Size(921, 26);
            this.txt_msg.TabIndex = 2;
            // 
            // btn_start
            // 
            this.btn_start.BackColor = System.Drawing.Color.Purple;
            this.btn_start.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_start.Location = new System.Drawing.Point(7, 16);
            this.btn_start.Margin = new System.Windows.Forms.Padding(2);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(98, 109);
            this.btn_start.TabIndex = 3;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = false;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btn_stop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_stop.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stop.Location = new System.Drawing.Point(6, 128);
            this.btn_stop.Margin = new System.Windows.Forms.Padding(2);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(99, 119);
            this.btn_stop.TabIndex = 4;
            this.btn_stop.Text = "Stop";
            this.btn_stop.UseVisualStyleBackColor = false;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::IK_Test.Properties.Resources.srivas_university;
            this.pictureBox1.Location = new System.Drawing.Point(492, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(98, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Yellow;
            this.label13.Location = new System.Drawing.Point(64, 11);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(389, 29);
            this.label13.TabIndex = 11;
            this.label13.Text = "Forward Kinematics Demonstration";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_stop);
            this.groupBox3.Controls.Add(this.btn_start);
            this.groupBox3.ForeColor = System.Drawing.Color.Aqua;
            this.groupBox3.Location = new System.Drawing.Point(2, 67);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(111, 258);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Control";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox4.Controls.Add(this.txt_j6);
            this.groupBox4.Controls.Add(this.txt_j5);
            this.groupBox4.Controls.Add(this.txt_j4);
            this.groupBox4.Controls.Add(this.txt_j3);
            this.groupBox4.Controls.Add(this.txt_j2);
            this.groupBox4.Controls.Add(this.txt_j1);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.hscroll_J6);
            this.groupBox4.Controls.Add(this.hscroll_J5);
            this.groupBox4.Controls.Add(this.hscroll_J4);
            this.groupBox4.Controls.Add(this.hscroll_J3);
            this.groupBox4.Controls.Add(this.hscroll_J2);
            this.groupBox4.Controls.Add(this.hscroll_J1);
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(118, 67);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(470, 258);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Joint Angle Input";
            // 
            // txt_j6
            // 
            this.txt_j6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j6.Location = new System.Drawing.Point(394, 220);
            this.txt_j6.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j6.Name = "txt_j6";
            this.txt_j6.Size = new System.Drawing.Size(67, 23);
            this.txt_j6.TabIndex = 2;
            this.txt_j6.Text = "0";
            this.txt_j6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j5
            // 
            this.txt_j5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j5.Location = new System.Drawing.Point(394, 182);
            this.txt_j5.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j5.Name = "txt_j5";
            this.txt_j5.Size = new System.Drawing.Size(67, 23);
            this.txt_j5.TabIndex = 2;
            this.txt_j5.Text = "0";
            this.txt_j5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j4
            // 
            this.txt_j4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j4.Location = new System.Drawing.Point(394, 141);
            this.txt_j4.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j4.Name = "txt_j4";
            this.txt_j4.Size = new System.Drawing.Size(67, 23);
            this.txt_j4.TabIndex = 2;
            this.txt_j4.Text = "0";
            this.txt_j4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j3
            // 
            this.txt_j3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j3.Location = new System.Drawing.Point(394, 103);
            this.txt_j3.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j3.Name = "txt_j3";
            this.txt_j3.Size = new System.Drawing.Size(67, 23);
            this.txt_j3.TabIndex = 2;
            this.txt_j3.Text = "0";
            this.txt_j3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j2
            // 
            this.txt_j2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j2.Location = new System.Drawing.Point(394, 65);
            this.txt_j2.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j2.Name = "txt_j2";
            this.txt_j2.Size = new System.Drawing.Size(67, 23);
            this.txt_j2.TabIndex = 2;
            this.txt_j2.Text = "0";
            this.txt_j2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_j1
            // 
            this.txt_j1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_j1.Location = new System.Drawing.Point(394, 28);
            this.txt_j1.Margin = new System.Windows.Forms.Padding(2);
            this.txt_j1.Name = "txt_j1";
            this.txt_j1.Size = new System.Drawing.Size(67, 23);
            this.txt_j1.TabIndex = 2;
            this.txt_j1.Text = "0";
            this.txt_j1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(13, 221);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(26, 20);
            this.label19.TabIndex = 1;
            this.label19.Text = "J6";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(13, 182);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(26, 20);
            this.label18.TabIndex = 1;
            this.label18.Text = "J5";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(10, 141);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(26, 20);
            this.label17.TabIndex = 1;
            this.label17.Text = "J4";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(10, 102);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 20);
            this.label16.TabIndex = 1;
            this.label16.Text = "J3";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(10, 65);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(26, 20);
            this.label15.TabIndex = 1;
            this.label15.Text = "J2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(12, 28);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 20);
            this.label14.TabIndex = 1;
            this.label14.Text = "J1";
            // 
            // hscroll_J6
            // 
            this.hscroll_J6.Location = new System.Drawing.Point(38, 220);
            this.hscroll_J6.Name = "hscroll_J6";
            this.hscroll_J6.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J6.TabIndex = 0;
            this.hscroll_J6.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J6_Scroll);
            // 
            // hscroll_J5
            // 
            this.hscroll_J5.Location = new System.Drawing.Point(38, 182);
            this.hscroll_J5.Name = "hscroll_J5";
            this.hscroll_J5.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J5.TabIndex = 0;
            this.hscroll_J5.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J5_Scroll);
            // 
            // hscroll_J4
            // 
            this.hscroll_J4.Location = new System.Drawing.Point(38, 141);
            this.hscroll_J4.Name = "hscroll_J4";
            this.hscroll_J4.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J4.TabIndex = 0;
            this.hscroll_J4.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J4_Scroll);
            // 
            // hscroll_J3
            // 
            this.hscroll_J3.Location = new System.Drawing.Point(38, 103);
            this.hscroll_J3.Name = "hscroll_J3";
            this.hscroll_J3.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J3.TabIndex = 0;
            this.hscroll_J3.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J3_Scroll);
            // 
            // hscroll_J2
            // 
            this.hscroll_J2.Location = new System.Drawing.Point(38, 65);
            this.hscroll_J2.Name = "hscroll_J2";
            this.hscroll_J2.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J2.TabIndex = 0;
            this.hscroll_J2.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J2_Scroll);
            // 
            // hscroll_J1
            // 
            this.hscroll_J1.Location = new System.Drawing.Point(38, 28);
            this.hscroll_J1.Name = "hscroll_J1";
            this.hscroll_J1.Size = new System.Drawing.Size(353, 27);
            this.hscroll_J1.TabIndex = 0;
            this.hscroll_J1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hscroll_J1_Scroll);
            // 
            // hScroll_RX
            // 
            this.hScroll_RX.Location = new System.Drawing.Point(44, 141);
            this.hScroll_RX.Name = "hScroll_RX";
            this.hScroll_RX.Size = new System.Drawing.Size(214, 23);
            this.hScroll_RX.TabIndex = 5;
            this.hScroll_RX.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_RX_Scroll);
            // 
            // hScroll_TZ
            // 
            this.hScroll_TZ.Location = new System.Drawing.Point(44, 101);
            this.hScroll_TZ.Name = "hScroll_TZ";
            this.hScroll_TZ.Size = new System.Drawing.Size(214, 21);
            this.hScroll_TZ.TabIndex = 3;
            this.hScroll_TZ.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_TZ_Scroll);
            // 
            // hScroll_RY
            // 
            this.hScroll_RY.Location = new System.Drawing.Point(44, 179);
            this.hScroll_RY.Name = "hScroll_RY";
            this.hScroll_RY.Size = new System.Drawing.Size(214, 23);
            this.hScroll_RY.TabIndex = 4;
            this.hScroll_RY.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_RY_Scroll);
            // 
            // hScroll_RZ
            // 
            this.hScroll_RZ.Location = new System.Drawing.Point(44, 217);
            this.hScroll_RZ.Name = "hScroll_RZ";
            this.hScroll_RZ.Size = new System.Drawing.Size(214, 23);
            this.hScroll_RZ.TabIndex = 3;
            this.hScroll_RZ.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_RZ_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(9, 27);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "TX";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(9, 141);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "RX";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(11, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "TY";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(7, 179);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "RY";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(10, 103);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "TZ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(7, 215);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "RZ";
            // 
            // txt_tx
            // 
            this.txt_tx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tx.Location = new System.Drawing.Point(261, 24);
            this.txt_tx.Margin = new System.Windows.Forms.Padding(2);
            this.txt_tx.Name = "txt_tx";
            this.txt_tx.Size = new System.Drawing.Size(67, 23);
            this.txt_tx.TabIndex = 11;
            this.txt_tx.Text = "0";
            this.txt_tx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_rx
            // 
            this.txt_rx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_rx.Location = new System.Drawing.Point(261, 140);
            this.txt_rx.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rx.Name = "txt_rx";
            this.txt_rx.Size = new System.Drawing.Size(67, 23);
            this.txt_rx.TabIndex = 11;
            this.txt_rx.Text = "0";
            this.txt_rx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ty
            // 
            this.txt_ty.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ty.Location = new System.Drawing.Point(261, 62);
            this.txt_ty.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ty.Name = "txt_ty";
            this.txt_ty.Size = new System.Drawing.Size(67, 23);
            this.txt_ty.TabIndex = 10;
            this.txt_ty.Text = "0";
            this.txt_ty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_ry
            // 
            this.txt_ry.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ry.Location = new System.Drawing.Point(261, 178);
            this.txt_ry.Margin = new System.Windows.Forms.Padding(2);
            this.txt_ry.Name = "txt_ry";
            this.txt_ry.Size = new System.Drawing.Size(67, 23);
            this.txt_ry.TabIndex = 10;
            this.txt_ry.Text = "0";
            this.txt_ry.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_tz
            // 
            this.txt_tz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tz.Location = new System.Drawing.Point(261, 100);
            this.txt_tz.Margin = new System.Windows.Forms.Padding(2);
            this.txt_tz.Name = "txt_tz";
            this.txt_tz.Size = new System.Drawing.Size(67, 23);
            this.txt_tz.TabIndex = 9;
            this.txt_tz.Text = "0";
            this.txt_tz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_rz
            // 
            this.txt_rz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_rz.Location = new System.Drawing.Point(261, 216);
            this.txt_rz.Margin = new System.Windows.Forms.Padding(2);
            this.txt_rz.Name = "txt_rz";
            this.txt_rz.Size = new System.Drawing.Size(67, 23);
            this.txt_rz.TabIndex = 9;
            this.txt_rz.Text = "0";
            this.txt_rz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_rz);
            this.groupBox1.Controls.Add(this.txt_tz);
            this.groupBox1.Controls.Add(this.txt_ry);
            this.groupBox1.Controls.Add(this.txt_ty);
            this.groupBox1.Controls.Add(this.txt_rx);
            this.groupBox1.Controls.Add(this.txt_tx);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.hScroll_RZ);
            this.groupBox1.Controls.Add(this.hScroll_RY);
            this.groupBox1.Controls.Add(this.hScroll_TZ);
            this.groupBox1.Controls.Add(this.hScroll_RX);
            this.groupBox1.Controls.Add(this.hScroll_TY);
            this.groupBox1.Controls.Add(this.hScroll_TX);
            this.groupBox1.Location = new System.Drawing.Point(592, 67);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(338, 258);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "IK Control";
            // 
            // hScroll_TY
            // 
            this.hScroll_TY.Location = new System.Drawing.Point(44, 63);
            this.hScroll_TY.Name = "hScroll_TY";
            this.hScroll_TY.Size = new System.Drawing.Size(214, 22);
            this.hScroll_TY.TabIndex = 4;
            this.hScroll_TY.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_TY_Scroll);
            // 
            // hScroll_TX
            // 
            this.hScroll_TX.Location = new System.Drawing.Point(44, 25);
            this.hScroll_TX.Name = "hScroll_TX";
            this.hScroll_TX.Size = new System.Drawing.Size(214, 22);
            this.hScroll_TX.TabIndex = 5;
            this.hScroll_TX.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScroll_TX_Scroll);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(938, 366);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txt_msg);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "frm_main";
            this.Text = "Forward Kinematics Demonstration";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_msg;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txt_j6;
        private System.Windows.Forms.TextBox txt_j5;
        private System.Windows.Forms.TextBox txt_j4;
        private System.Windows.Forms.TextBox txt_j3;
        private System.Windows.Forms.TextBox txt_j2;
        private System.Windows.Forms.TextBox txt_j1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.HScrollBar hscroll_J6;
        private System.Windows.Forms.HScrollBar hscroll_J5;
        private System.Windows.Forms.HScrollBar hscroll_J4;
        private System.Windows.Forms.HScrollBar hscroll_J3;
        private System.Windows.Forms.HScrollBar hscroll_J2;
        private System.Windows.Forms.HScrollBar hscroll_J1;
        private System.Windows.Forms.HScrollBar hScroll_RX;
        private System.Windows.Forms.HScrollBar hScroll_TZ;
        private System.Windows.Forms.HScrollBar hScroll_RY;
        private System.Windows.Forms.HScrollBar hScroll_RZ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_tx;
        private System.Windows.Forms.TextBox txt_rx;
        private System.Windows.Forms.TextBox txt_ty;
        private System.Windows.Forms.TextBox txt_ry;
        private System.Windows.Forms.TextBox txt_tz;
        private System.Windows.Forms.TextBox txt_rz;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.HScrollBar hScroll_TY;
        private System.Windows.Forms.HScrollBar hScroll_TX;
    }
}

