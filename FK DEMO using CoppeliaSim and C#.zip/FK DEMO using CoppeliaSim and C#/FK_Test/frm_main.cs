﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tools;

namespace IK_Test
{
    public partial class frm_main : Form
    {
        bool kinematics_Operation = true;

        CoppeliaBlueRobot rbt = new CoppeliaBlueRobot();

        //arm ar;


        //string dh_param =
        //       "0.174532925,-1.570796327,169.77,64.2," +
        //       "-1.570796327,0,0,305," +
        //       "0.1745322925,1.570796327,0,0," +
        //       "0.785398163,-1.570796327,-222.63,0," +
        //       "0.436332313,1.570796327,0,0," +
        //       "3.926990817,0,-36.25,0";

       


        //double X = 311.0331182;
        //double Y = 43.84360337;
        //double Z = 419.7374896;
        //double y = 6.307994695;
        //double p = 116.8511973;
        //double r = -80.43052397;

        //txt_msg.Text= arm.IK(X, Y, Z, y, p, r);


        //arm.push_angle_to_DH_Param("25,50,75,100,125,150");
        //    //string angle = "10,-90,100,45,25,45";/
        //    //string pos = arm.get_position(angle);
        //    txt_msg.Text = arm.Get_FK();
















        public frm_main()
        {
            InitializeComponent();
        }
        //___________________________________________________________________________________________________
        private void Form1_Load(object sender, EventArgs e)
        {
            utilUI.h_slider_Config(hscroll_J1, -1800, 1800, 1);
            utilUI.h_slider_Config(hscroll_J2, -1800, 1800, 1);
            utilUI.h_slider_Config(hscroll_J3, -1800, 1800, 1);
            utilUI.h_slider_Config(hscroll_J4, -1800, 1800, 1);
            utilUI.h_slider_Config(hscroll_J5, -1800, 1800, 1);
            utilUI.h_slider_Config(hscroll_J6, -1800, 1800, 1);

            utilUI.h_slider_Config(hScroll_TX, -100, 100, 1);
            utilUI.h_slider_Config(hScroll_TY, -100, 100, 1);
            utilUI.h_slider_Config(hScroll_TZ, -100, 100, 1);
            utilUI.h_slider_Config(hScroll_RX, -100, 100, 1);
            utilUI.h_slider_Config(hScroll_RY, -100, 100, 1);
            utilUI.h_slider_Config(hScroll_RZ, -100, 100, 1);


            //  ar = new arm(6, dh_param);

            timer1.Enabled = false;
            timer1.Interval = 1;
        }
        //___________________________________________________________________________________________________
        private void btn_connect_Click(object sender, EventArgs e)
        {
            //rbt.Initialize();
            //txt_msg.Text = rbt.message;
        }
        //___________________________________________________________________________________________________
        private void btn_start_Click(object sender, EventArgs e)
        {
           rbt.start();
           timer1.Enabled = true;
        }
        //___________________________________________________________________________________________________
        private void btn_stop_Click(object sender, EventArgs e)
        {
            
            //rbt.stop();
           // timer1.Enabled = false;
        }
        //___________________________________________________________________________________________________
        private void button1_Click_1(object sender, EventArgs e) 
        {
            //rbt.send_joint();
            //rbt.Get_Object_Matrix();
        }
        //___________________________________________________________________________________________________
        private void btn_position_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 1;
        }
        //___________________________________________________________________________________________________
        private void timer1_Tick(object sender, EventArgs e)
        {
            if(kinematics_Operation)
            {
                push_data();
            }
            else
            {
                push_IK_data();
            }
            
           // txt_msg.Text = rbt.strEcho;
            //rbt.Get_Object_Matrix();
            // txt_msg.Text= rbt.Get_Position();
        }
        //___________________________________________________________________________________________________
        private void btn_send_Click(object sender, EventArgs e)
        {
            string val="";
            int joint = 0;

            //rbt.send_joint_ok(txt_j1.Text, 1);
            //rbt.send_joint_ok(txt_j2.Text, 2);
            //rbt.send_joint_ok(txt_j3.Text, 3);
            //rbt.send_joint_ok(txt_j4.Text, 4);
            //rbt.send_joint_ok(txt_j5.Text, 5);
            //rbt.send_joint_ok(txt_j6.Text, 6);


            //if (rbtn_j1.Checked) { val = txt_j1.Text; joint = 1; }
            //if (rbtn_j2.Checked) { val = txt_j2.Text; joint = 2; }
            //if (rbtn_j3.Checked) { val = txt_j3.Text; joint = 3; }
            //if (rbtn_j4.Checked) { val = txt_j4.Text; joint = 4; }
            //if (rbtn_j5.Checked) { val = txt_j5.Text; joint = 5; }
            //if (rbtn_j6.Checked) { val = txt_j6.Text; joint = 6; }

            //if (rbt.send_joint_ok(val,joint)) btn_send.BackColor = Color.Green;
            //else btn_send.BackColor = Color.Red;
        }
        //___________________________________________________________________________________________________
        private void button2_Click(object sender, EventArgs e)
        {
            tcp_client client = new tcp_client("127.0.0.1", 6000);
            client.connect();
            if(client.connected)
            {
                client.close();
            }



            //double X = 311.0331182;
            //double Y = 43.84360337;
            //double Z = 419.7374896;
            //double y = 6.307994695;
            //double p = 116.8511973;
            //double r = -80.43052397;

            //txt_msg.Text = ar.IK(X, Y, Z, y, p, r);


            //rbt.Get_Position();
            //rbt.Get_Object_Matrix();
        }
        //___________________________________________________________________________________________________
        private void button3_Click(object sender, EventArgs e)
        {

        }
        //___________________________________________________________________________________________________     
        private void hscroll_J1_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j1.Text = (hscroll_J1.Value/10.0).ToString();
            push_data();
            kinematics_Operation = true;
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J2_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j2.Text = (hscroll_J2.Value / 10.0).ToString();
            kinematics_Operation = true;
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J3_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j3.Text = (hscroll_J3.Value/10.0).ToString();
            push_data();
            kinematics_Operation = true;
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J4_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j4.Text = (hscroll_J4.Value/10.0).ToString();
            push_data();
            kinematics_Operation = true;
        }
        //___________________________________________________________________________________________________     
        private void hscroll_J5_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j5.Text = (hscroll_J5.Value/10.0).ToString();
            push_data();
            kinematics_Operation = true;
        }
        //___________________________________________________________________________________________________     
         private void hscroll_J6_Scroll(object sender, ScrollEventArgs e)
        {
            txt_j6.Text = (hscroll_J6.Value/10.0).ToString();
            push_data();
            kinematics_Operation = true;
        }
        //___________________________________________________________________________________________________
        public void push_data()
        {
            rbt.push_FK_Data(txt_j1.Text, txt_j2.Text, txt_j3.Text, txt_j4.Text, txt_j5.Text, txt_j6.Text);
        }
        //___________________________________________________________________________________________________
        public void push_IK_data()
        {
            rbt.push_IK_Data(txt_tx.Text, txt_ty.Text, txt_tz.Text, txt_rx.Text, txt_ry.Text, txt_rz.Text);
        }
        //___________________________________________________________________________________________________
        private void hScroll_TX_Scroll(object sender, ScrollEventArgs e)
        {
            txt_tx.Text = (hScroll_TX.Value / 100.0).ToString();
            push_IK_data();
            kinematics_Operation = false;
        }
        //___________________________________________________________________________________________________
        private void hScroll_TY_Scroll(object sender, ScrollEventArgs e)
        {
            txt_ty.Text = (hScroll_TY.Value / 100.0).ToString();
            push_IK_data();
            kinematics_Operation = false;
        }
        //___________________________________________________________________________________________________
        private void hScroll_TZ_Scroll(object sender, ScrollEventArgs e)
        {
            txt_tz.Text = (hScroll_TZ.Value / 100.0).ToString();
            push_IK_data();
            kinematics_Operation = false;
        }
        //___________________________________________________________________________________________________
        private void hScroll_RX_Scroll(object sender, ScrollEventArgs e)
        {
            txt_rx.Text = (hScroll_RX.Value / 10.0).ToString();
            push_IK_data();
            kinematics_Operation = false;
        }
        //___________________________________________________________________________________________________
        private void hScroll_RY_Scroll(object sender, ScrollEventArgs e)
        {
            txt_ry.Text = (hScroll_RY.Value / 10.0).ToString();
            push_IK_data();
            kinematics_Operation = false;
        }
        //___________________________________________________________________________________________________
        private void hScroll_RZ_Scroll(object sender, ScrollEventArgs e)
        {
            txt_rz.Text = (hScroll_RZ.Value / 10.0).ToString();
            push_IK_data();
            kinematics_Operation = false;
        }
        //___________________________________________________________________________________________________




    }
}