﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
//using OpenCvSharp;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Tools;
using System.Security.Permissions;
using System.Drawing;
using System.Timers;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tools
{
   public static class utilUI
    {
        public static void h_slider_Config(HScrollBar hs, int min, int max, int interval)
        {
            hs.Minimum = min;
            hs.Maximum = max;
            hs.SmallChange = interval;
        }
        //____________________________________________________________________________________














































    }// class
}// namespace
