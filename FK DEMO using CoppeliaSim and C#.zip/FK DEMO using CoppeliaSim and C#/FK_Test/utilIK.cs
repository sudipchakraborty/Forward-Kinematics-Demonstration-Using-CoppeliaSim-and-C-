﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//using MathNet.Numerics.LinearAlgebra;
//using MathNet.Numerics.LinearAlgebra.Double;
//using SharpGL;


//MathNet.Numerics  
//MathNet.Numerics.FSharp  
namespace Tools
{
    public static class utilIK
    {
            public static double ToRadians(this double angleIn10thofaDegree)
            {
                // Angle in 10th of a degree
                return (angleIn10thofaDegree * Math.PI) / 180;
            }
        //________________________________________________________________________
        public static double ToDegrees(double radians)
        {
            double degrees = (180 / Math.PI) * radians;
            return (degrees);
        }
        //_________________________________________________________________________
        public static double[] Get_Identity()
        {
            double[] mat = new double[16];
            mat[0] = 1; mat[4] = 0; mat[8] = 0; mat[12] = 0;
            mat[1] = 0; mat[5] = 1; mat[9] = 0; mat[13] = 0;
            mat[2] = 0; mat[6] = 0; mat[10] = 1; mat[14] = 0;
            mat[3] = 0; mat[7] = 0; mat[11] = 0; mat[15] = 1;

            return mat;
        }
        //_________________________________________________________________________
        public static float[] LoadIdentity (float[] mat)
        {
            mat[0] = 1; mat[4] = 0; mat[8] = 0;   mat[12] = 0;
            mat[1] = 0; mat[5] = 1; mat[9] = 0;   mat[13] = 0;
            mat[2] = 0; mat[6] = 0; mat[10] = 1;  mat[14] = 0;
            mat[3] = 0; mat[7] = 0; mat[11] = 0;  mat[15] = 1;

            return mat;
        }
        //________________________________________________________________________
        public static float[] Translate(string dir,float val,float[] mat)
        {
            if(dir=="x")
            {
                mat[12] += val;
            }

            if (dir == "y")
            {
                mat[13] += val;
            }

            if (dir == "z")
            {
                mat[14] += val;
            }

            return mat;
        }
        //________________________________________________________________________
       


        public static void MultiplyMatrix()
        {

            //gl.PushMatrix();

            //            //gl.LoadMatrixf(m);

            //gl.LoadIdentity();

            //GL.glLoadIdentity();
            //GL.glRotatef(theta, 0, 1, 0); //theta
            //GL.glTranslatef(0, d, 0); // d
            //GL.glTranslatef(r, 0, 0); // r
            //GL.glRotatef(alph, 1, 0, 0);// alpha
            //GL.glPopMatrix();




            //float[] m = new float[16];

            //OpenGL gl = new OpenGL();

            //gl.PushMatrix();

            //gl.LoadIdentity();


            //gl.Translate(0, 0, 0);

            //gl.Rotate(0, 0, 0, 0);


            //gl.MultMatrix(m);

            //gl.GetFloat(OpenGL.GL_MODELVIEW_MATRIX,m);

            //gl.PopMatrix();

            ////  Clear the color and depth buffer.
            ////gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

            ////  Load the identity matrix.


            //gl.LoadMatrixf(matrixView);              // Mmv = Mv
            //gl.MultMatrixf(matrixModel);             // Mmv *= Mm


            ////  Rotate around the Y axis.
            //gl.Rotate(rotation, 0.0f, 1.0f, 0.0f);

            ////  Draw a coloured pyramid.
            //gl.Begin(OpenGL.GL_TRIANGLES);
            //gl.Color(1.0f, 0.0f, 0.0f);
            //gl.Vertex(0.0f, 1.0f, 0.0f);
            //gl.Color(0.0f, 1.0f, 0.0f);
            //gl.Vertex(-1.0f, -1.0f, 1.0f);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Vertex(1.0f, -1.0f, 1.0f);
            //gl.Color(1.0f, 0.0f, 0.0f);
            //gl.Vertex(0.0f, 1.0f, 0.0f);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Vertex(1.0f, -1.0f, 1.0f);
            //gl.Color(0.0f, 1.0f, 0.0f);
            //gl.Vertex(1.0f, -1.0f, -1.0f);
            //gl.Color(1.0f, 0.0f, 0.0f);
            //gl.Vertex(0.0f, 1.0f, 0.0f);
            //gl.Color(0.0f, 1.0f, 0.0f);
            //gl.Vertex(1.0f, -1.0f, -1.0f);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Vertex(-1.0f, -1.0f, -1.0f);
            //gl.Color(1.0f, 0.0f, 0.0f);
            //gl.Vertex(0.0f, 1.0f, 0.0f);
            //gl.Color(0.0f, 0.0f, 1.0f);
            //gl.Vertex(-1.0f, -1.0f, -1.0f);
            //gl.Color(0.0f, 1.0f, 0.0f);
            //gl.Vertex(-1.0f, -1.0f, 1.0f);
            //gl.End();

            ////  Nudge the rotation.
            //rotation += 3.0f;

            //Matrix mat=new 
            //c = new int[m1, n2];
            //for (int i = 0; i < m1; i++)
            //{
            //    for (int j = 0; j < n2; j++)
            //    {
            //        c[i, j] = 0;
            //        for (int k = 0; k < n1; k++) c[i, j] = c[i, j] + a[i, k] * b[k, j];
            //    }
            //}
        }
        //________________________________________________________________________




    }
}








//   mat = get_transform(mat);

//  OpenGL  gl = openGLControl1.OpenGL;


//   gl.LoadMatrixf(mat);

//// Create the appropriate projection matrix.
//   gl.MatrixMode(OpenGL.GL_PROJECTION);

//   gl.PushMatrix();

//   gl.LoadIdentity();
//   gl.Translate(0, 0, .5f);
//   gl.Rotate(30,1, 0, 0);


//double[] val = new double[16];
//frm_matrix mat = new frm_matrix(val);
//mat.Show();


//   float[] modelview=new float[16];
//   gl.GetFloat(OpenGL.GL_MODELVIEW_MATRIX, modelview);


//   gl.PopMatrix();


//   gl.LoadIdentity();

//   gl.LineWidth(5);

//   double[,] mat = new double[4, 4];


//   //  Setup the modelview matrix.
//   gl.MatrixMode(OpenGL.GL_MODELVIEW);
//   gl.LoadIdentity();
//  // gl.MultMatrix()


//  //   Matrix mat1 = new Matrix([4,4]);

//  gl.Begin(OpenGL.GL_LINE_LOOP);
////  gl.DrawText3D("a", 0.2f, 1.0f, "osX: 0");
//  for (int i = 0; i < 200; i++)
//  {
//      float theta = 2.0f * 3.1415926f * (float)i / 200f;//get the current angle

//      float x = 3f * (float)System.Math.Cos(theta);//calculate the x component
//      float y = 3f * (float)System.Math.Sin(theta);//calculate the y component

//      gl.Color(1.0f, 1.0f, 1.0f);
//      gl.Vertex(0f, y + 0.0f, x + 0.0f);//output vertex

//  }

//  gl.End();

// gl.LoadIdentity();

//gl.Color(0.85f, 0.85f, 0.85f, 0.5f);

//gl.Begin(OpenGL.GL_QUADS);
//for (int i = 0; i < 1; i++)
//{
//    this.draw_sphere(gl, 3);
//}
//gl.End();

//gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);	// Clear The Screen And The Depth Buffer
//gl.Begin(OpenGL.GL_QUADS);

//gl.LoadIdentity();

//gl.Color(1.0f, 0.0f, 1.0f);
////gl.Vertex(-1.0f, 1.0f, 1.0f);

////gl.Rotate(1, 1, 1);
////gl.Rotate(4,1, 1, 1);

////gl.Translate(1, 1, 1);

////gl.LineWidth(0.5f);

//// openGLControl1.OpenGLDraw()

//gl.End();						// Done Drawing The Q
//gl.Flush();



//gl.Enable(OpenGL.GL_BLEND);
//gl.BlendFunc(OpenGL.GL_SRC_ALPHA, OpenGL.GL_ONE_MINUS_SRC_ALPHA);

////  Draw a coloured parallelepiped.
//gl.Begin(OpenGL.GL_QUADS);

//gl.Color(0.0f, 1.0f, 0.0f);
//gl.Vertex(-2.0f, -0.25f, -1.0f);

//gl.Color(0.0f, 1.0f, 0.0f);
//gl.Vertex(2.0f, -0.25f, -1.0f);

//gl.Color(0.0f, 1.0f, 0.0f);
//gl.Vertex(2.0f, 0.25f, -1.0f);

//gl.Color(0.0f, 1.0f, 0.0f);
//gl.Vertex(-2.0f, 0.25f, -1.0f);






//gl.PushMatrix();

//            //gl.LoadMatrixf(m);

//gl.LoadIdentity();

//GL.glLoadIdentity();
//GL.glRotatef(theta, 0, 1, 0); //theta
//GL.glTranslatef(0, d, 0); // d
//GL.glTranslatef(r, 0, 0); // r
//GL.glRotatef(alph, 1, 0, 0);// alpha
//GL.glPopMatrix();

//Static float[] m = new float[16];
//Add the following codeGL.glGetFloatv(GL.GL_MODELVIEW_MATRIX, m);
//gl.GetFloat(OpenGL.GL_MODELVIEW_MATRIX, m);


